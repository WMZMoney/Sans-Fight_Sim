﻿{
	"version": 1641207520,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/clockface-sheet0.png",
		"images/minutehand-sheet0.png",
		"images/hourhand-sheet0.png",
		"images/secondhand-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}