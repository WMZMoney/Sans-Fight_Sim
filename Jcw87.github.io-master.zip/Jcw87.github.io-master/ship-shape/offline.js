﻿{
	"version": 1605757590,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-3.4.1.min.js",
		"offlineClient.js",
		"images/background-sheet0.png",
		"images/pressuremeter-sheet0.png",
		"images/pressurewalrus-sheet0.png",
		"media/shipshape.ogg",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png"
	]
}